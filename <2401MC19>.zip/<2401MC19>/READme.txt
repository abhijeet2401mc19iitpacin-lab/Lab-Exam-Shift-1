MA3105 xv6 Lab Solution Package
================================

This ZIP contains the three new C source files:
  sem.c
  synctest.c
  memtest.c

// Abhijeet Ghosh
// 2401MC19

QUESTION 1: SEMAPHORE INTEGRATION
---------------------------------
1. Add sem.o to the kernel OBJS list in Makefile.
2. Add these declarations to defs.h:
     void seminit(void);
     int sem_init(int, int);
     int sem_wait(int);
     int sem_post(int);
3. Call seminit() in main() before userinit().
4. Add syscall numbers in syscall.h:
     #define SYS_sem_init 22
     #define SYS_sem_wait 23
     #define SYS_sem_post 24
   Check that these numbers do not collide with existing definitions.
5. In syscall.c, declare sys_sem_init/sys_sem_wait/sys_sem_post and
   add their entries to the syscalls[] table.
6. Add the handlers to sysproc.c:
     int sys_sem_init(void) {
       int id, value;
       if(argint(0, &id) < 0 || argint(1, &value) < 0) return -1;
       return sem_init(id, value);
     }
     int sys_sem_wait(void) {
       int id;
       if(argint(0, &id) < 0) return -1;
       return sem_wait(id);
     }
     int sys_sem_post(void) {
       int id;
       if(argint(0, &id) < 0) return -1;
       return sem_post(id);
     }
7. Add prototypes to user.h:
     int sem_init(int, int);
     int sem_wait(int);
     int sem_post(int);
8. Add to usys.S:
     SYSCALL(sem_init)
     SYSCALL(sem_wait)
     SYSCALL(sem_post)
9. Add _synctest to UPROGS in Makefile.

QUESTION 2: MEMORY SYSTEM-CALL INTEGRATION
-----------------------------------------
1. In kalloc.c, add an integer freepages field to kmem.
   Initialize it to zero at the beginning of kinit1(), BEFORE freerange().
   Increment it whenever kfree() successfully puts a page on the free list.
   Decrement it whenever kalloc() successfully removes a page.
   Use kmem.lock whenever kmem.use_lock is enabled.
2. Add this function to kalloc.c:
     int getfreepages(void) {
       int n;
       if(kmem.use_lock) acquire(&kmem.lock);
       n = kmem.freepages;
       if(kmem.use_lock) release(&kmem.lock);
       return n;
     }
3. In defs.h add:
     int getfreepages(void);
     int get_physical_address(pde_t*, uint);
   Put the second declaration after pde_t is defined/available.
4. In vm.c, after the static walkpgdir() definition, add:
     int get_physical_address(pde_t *pgdir, uint va) {
       pte_t *pte = walkpgdir(pgdir, (char*)va, 0);
       if(pte == 0 || !(*pte & PTE_P) || !(*pte & PTE_U))
         return -1;
       return (int)(PTE_ADDR(*pte) + (va & 0xFFF));
     }
5. Add syscall numbers in syscall.h:
     #define SYS_freepages 25
     #define SYS_va2pa 26
   Check for number collisions.
6. In syscall.c, declare sys_freepages/sys_va2pa and add their
   entries to syscalls[].
7. Add handlers to sysproc.c:
     int sys_freepages(void) { return getfreepages(); }
     int sys_va2pa(void) {
       int va;
       if(argint(0, &va) < 0) return -1;
       return get_physical_address(myproc()->pgdir, (uint)va);
     }
8. Add prototypes to user.h:
     int freepages(void);
     int va2pa(int);
9. Add to usys.S:
     SYSCALL(freepages)
     SYSCALL(va2pa)
10. Add _memtest to UPROGS in Makefile.

BUILD AND TEST
--------------
From the xv6-public directory:
  make clean
  make qemu-nox CPUS=1

At the xv6 shell:
  echo YOUR_ROLL_NUMBER
  synctest
  memtest

Exit QEMU with Ctrl-a then x.

Before submission, inspect compiler errors and verify:
- synctest prints A B C repeated five times, then Done.
- va2pa returns -1 for an unmapped or non-user page.
- parent and child have the same global virtual address but different
  physical addresses.
- after child exit and wait(), freepages() returns to its pre-fork value.

Then run make clean and create the required archive from the full xv6
directory, as specified by the examination paper.
