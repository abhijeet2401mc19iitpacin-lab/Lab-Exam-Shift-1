#include "types.h"
#include "stat.h"
#include "user.h"

int global_var = 100;

int
main(void)
{
  int initial, after_sbrk, before_fork;
  int pid, pa;

  initial = freepages();
  printf(1, "Free pages at startup: %d\n", initial);

  if(sbrk(10 * 4096) == (char*)-1) {
    printf(1, "sbrk failed\n");
    exit();
  }

  after_sbrk = freepages();
  printf(1, "Free pages after sbrk: %d\n", after_sbrk);

  printf(1, "Global variable value: %d\n", global_var);
  printf(1, "Global virtual address: %x\n", (uint)&global_var);
  pa = va2pa((int)&global_var);
  printf(1, "Global physical address: %x\n", pa);

  printf(1, "va2pa(0x7FFFFFFF): %d\n", va2pa(0x7FFFFFFF));

  before_fork = freepages();
  printf(1, "Free pages before fork: %d\n", before_fork);

  pid = fork();
  if(pid < 0) {
    printf(1, "fork failed\n");
    exit();
  }

  if(pid == 0) {
    printf(1, "\nChild:\n");
    printf(1, "Virtual address: %x\n", (uint)&global_var);
    printf(1, "Physical address: %x\n", va2pa((int)&global_var));
    printf(1, "Free pages in child: %d\n", freepages());
    exit();
  }

  printf(1, "\nParent:\n");
  printf(1, "Virtual address: %x\n", (uint)&global_var);
  printf(1, "Physical address: %x\n", va2pa((int)&global_var));
  printf(1, "Free pages after fork: %d\n", freepages());

  wait();

  printf(1, "\nAfter child exit and wait:\n");
  printf(1, "Free pages: %d\n", freepages());
  printf(1, "Free pages before fork: %d\n", before_fork);

  if(freepages() == before_fork)
    printf(1, "Memory successfully recovered!\n");
  else
    printf(1, "Memory count mismatch!\n");

  exit();
}
